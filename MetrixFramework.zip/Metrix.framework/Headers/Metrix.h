//
//  Metrix.h
//  Metrix
//
//  Created by Matin on 9/20/20.
//  Copyright © 2020 Metrix. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for Metrix.
FOUNDATION_EXPORT double MetrixVersionNumber;

//! Project version string for Metrix.
FOUNDATION_EXPORT const unsigned char MetrixVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Metrix/PublicHeader.h>


